﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;



namespace WinSoftDemo.Models
{
    public class DepartmentDbhandle
    {
        private SqlConnection con;
        private void connection()
        {
            string constring = ConfigurationManager.ConnectionStrings["StudentConn"].ToString();
            con = new SqlConnection(constring);
        }

        public bool AddDepartment(BlogPost smodel)
        {
            connection();
            SqlCommand cmd = new SqlCommand("InsertBlogPost", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@Title", smodel.Title);      
            cmd.Parameters.AddWithValue("@Description", smodel.Content);
            cmd.Parameters.AddWithValue("@ImagePath", smodel.ImagePath);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i >= 1)
                return true;
            else
                return false;
        }

        internal bool AddDepartment(object smodel)
        {
            throw new NotImplementedException();
        }

         //********** VIEW DEPARTMENT  DETAILS********************
        public List<BlogPost> GetBlogDetails()
        {
            connection();
            List<BlogPost> blog = new List<BlogPost>();

            SqlCommand cmd = new SqlCommand("GetBlogpostDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            con.Open();
            sd.Fill(dt);
            con.Close();

            foreach (DataRow dr in dt.Rows)
            {
                blog.Add(
                    new BlogPost
                    {
                        Id = Convert.ToInt32(dr["BlogID"]),
                        Title = Convert.ToString(dr["Title"]),
                        Content = Convert.ToString(dr["Description"])
                    });
            }
            return blog;
        }

        //public bool UpdateDetails(DepartMent smodel)
        //{
        //    connection();
        //    SqlCommand cmd = new SqlCommand("UpdateDepartMentDetails", con);
        //    cmd.CommandType = CommandType.StoredProcedure;

        //    cmd.Parameters.AddWithValue("@StdId", smodel.Id);
        //    cmd.Parameters.AddWithValue("@Name", smodel.Code);
        //    cmd.Parameters.AddWithValue("@City", smodel.Department);

        //    con.Open();
        //    int i = cmd.ExecuteNonQuery();
        //    con.Close();

        //    if (i >= 1)
        //        return true;
        //    else
        //        return false;
        //}
    }
}